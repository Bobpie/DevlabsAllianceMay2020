package com.servicenow.testcases;

import org.testng.annotations.Test;

import com.servicenow.base.ProjectBase;
import com.servicenow.pages.LoginPage;

public class TC001_Login_Logout extends ProjectBase{
	@Test
	public void runTC001() {
		// driver = 1
//		LoginPage page = new LoginPage();
		new LoginPage(driver).enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLogout();
		
	}
}
