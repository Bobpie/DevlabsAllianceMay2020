package com.servicenow.pages;

import com.servicenow.base.ProjectBase;

public class CreateIncidentPage extends ProjectBase{
public void selectCaller() {
	
}
public void enterShortDescription() {
	
}
public void clickSubmitButton() {
	
}
}
