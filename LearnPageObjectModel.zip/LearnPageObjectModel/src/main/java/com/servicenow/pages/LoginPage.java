package com.servicenow.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.servicenow.base.ProjectBase;

public class LoginPage extends ProjectBase{
	// driver = null
	public LoginPage(RemoteWebDriver Driver) {
		// driver -> null to 1
		this.driver = Driver;
	}
public LoginPage enterUsername() {
	driver.switchTo().frame("gsft_main");
	driver.findElement(By.id("user_name")).sendKeys("admin");
//	LoginPage page = new LoginPage();
//	return new LoginPage();
	return this;
}
public LoginPage enterPassword() {
	driver.findElement(By.id("user_password")).sendKeys("Moa2QIQou0GO");
//	LoginPage page = new LoginPage();
	return this;
}
public HomePage clickLoginButton() {
	driver.findElement(By.id("sysverb_login")).click();
//	HomePage page = new HomePage();
	// driver = 2
	return new HomePage(driver);
}
public void selectLanguageDropDown() {
	
}
public void clickForgetPasswordLink() {
	
}
}
