package com.servicenow.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.servicenow.base.ProjectBase;

public class HomePage extends ProjectBase{
	//driver = null
public HomePage(RemoteWebDriver driver) {
	// driver -> null to 2
		this.driver = driver;
	}
public void enterFilter() {
	
}
public void createNewIncident() {
	
}
public LoginPage clickLogout() {
	driver.findElement(By.id("user_info_dropdown")).click();
	WebDriverWait wait = new WebDriverWait(driver, 15);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Logout")))).click();
	return new LoginPage(driver);
}

}
