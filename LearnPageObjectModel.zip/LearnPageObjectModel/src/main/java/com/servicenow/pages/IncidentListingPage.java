package com.servicenow.pages;

import com.servicenow.base.ProjectBase;

public class IncidentListingPage extends ProjectBase{
public void verifyIncidentCreation() {
	
}
}
